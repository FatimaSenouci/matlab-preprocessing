# DeepHistopathology
Deep Learning breast histology microscopy image recognition using Convolutional Neural Networks
